export enum InboxType {
    Inbox = 0,
    Drafts = 1,
    Sent = 2,
    AllMail = 3
}
